export class UsuarioModel {
  email: string;
  password: string;
  nombre: string;
}
