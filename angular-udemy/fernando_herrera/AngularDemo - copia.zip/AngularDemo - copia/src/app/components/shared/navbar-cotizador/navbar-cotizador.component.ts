import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-cotizador',
  templateUrl: './navbar-cotizador.component.html',
  styleUrls: ['./navbar-cotizador.component.css']
})
export class NavbarCotizadorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
